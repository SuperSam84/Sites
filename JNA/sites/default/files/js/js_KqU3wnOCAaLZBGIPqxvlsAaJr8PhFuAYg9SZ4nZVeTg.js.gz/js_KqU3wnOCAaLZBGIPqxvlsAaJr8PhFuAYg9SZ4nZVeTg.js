!function(a,b){Drupal.behaviors.ATfastclickInitialize={attach:function(a){FastClick.attach(b.body)}}}(jQuery,document);;
